import React, { useState, useEffect } from 'react';
import axios from 'axios';

import './App.css';
import Spinner from './Spinner';

function Register(props) {
	let [name, setName] = useState(null);
	let [email, setEmail] = useState(null);
	let [phoneNumber, setPhoneNumber] = useState(null);
	let [college, setCollege] = useState(null);
	let [notification, setNotification] = useState(null);
	let [loading, setLoading] = useState(false);

	useEffect(() => {
		setTimeout(() => {
			setNotification(null);
		}, 5000);
	}, [notification]);

	function handleSubmit(e) {
		e.preventDefault();
		if (!name) return setNotification('Name field cannot be empty !');
		if (!email) return setNotification('Email field cannot be empty !');
		if (!phoneNumber) return setNotification('Phone number field cannot be empty !');
		if (!college) return setNotification('College field cannot be empty !');
		if (phoneNumber.toString().length !== 10) return setNotification('Phone number not valid');
		setLoading(true);
		const userData = { name, email, phoneNumber, college };
		axios
			.post('/', userData)
			.then(res => {
				const data = res.data;
				if (data.success === true) setNotification(`${data.msg}\nYour Registered ID is ${data.id}`);
				else {
					console.log(data.err);
					setNotification(data.err);
				}
			})
			.catch(err => {
				console.log(err);
				setNotification('No Internet Connection !');
			})
			.finally(() => setLoading(false));
	}

	return (
		<div className='App'>
			{notification !== null && <div>{notification}</div>}
			{loading && <Spinner />}
			{!loading && (
				<form onSubmit={handleSubmit}>
					<input type='text' name='user' placeholder='name' value={name} onChange={e => setName(e.target.value)} />
					<input type='email' name='email' placeholder='email' value={email} onChange={e => setEmail(e.target.value)} />
					<input
						type='number'
						name='phoneNumber'
						placeholder='phone number'
						value={phoneNumber}
						onChange={e => setPhoneNumber(e.target.value)}
					/>
					<input type='text' name='college' placeholder='college' value={college} onChange={e => setCollege(e.target.value)} />
					<input type='submit' value='Submit' />
				</form>
			)}
		</div>
	);
}

export default Register;
